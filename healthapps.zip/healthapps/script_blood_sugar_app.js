var lowCounter = 0
var highCounter = 0

window.addEventListener("load", () => {
    document.body.classList.add("loaded"); 

    const element = document.querySelector('.chart-x')

    element.addEventListener('transitionstart', function(){
        if(lowCounter == 1 ) {
            alert("Consult Doctor Immediately ! Blood Sugar Level is very low !")
        }
        lowCounter = lowCounter + 1
        
        //var node = document.getElementsByTagName('alert');
        //node.parentNode.removeChild(node);
    });
    element.addEventListener('transitionend', function() {
        if(highCounter == 3) {
            alert("You are doing Good Job ! Blood Sugar level is improving !")
           }
           if(highCounter == 5) {
            alert("Blood Sugar is slowly rising! Take precautions!")
           }
           
        if(highCounter == 7) {
               alert("Consult Doctor Immediately ! Blood Sugar Level is very high !")
        }
        highCounter = highCounter + 1
    });

   });


function trnsitionFunction(event) {
    var element = document.querySelector('.chart-x')
    const style = getComputedStyle(element)

    console.log(event.propertyName)
    console.log(event.elapsedTime)
    console.log(event.pseudoElement)

    console.log(style.transitionProperty)
    console.log(style.transitionDuration)
    console.log(style.height)
  }
var lowCounter = 0
var highCounter = 0

window.addEventListener("load", () => {
    document.body.classList.add("loaded"); 

    const element = document.querySelector('.chart-x')

  

    element.addEventListener('transitionstart', function(){
        if(lowCounter == 1) {
         alert("Consult Doctor Immediately ! Oxygen Level is very low !")
        }
        lowCounter = lowCounter + 1
        
        //var node = document.getElementsByTagName('alert');
        //node.parentNode.removeChild(node);
    });
    element.addEventListener('transitionend', function() {
        if(highCounter == 3) {
         alert("You are doing Good Job ! Oxygen level is improving !")
        }
        
        if(highCounter == 7) {
            alert("Great Job ! You are in best health!")
        }
        highCounter = highCounter + 1
    });

    

   });





function trnsitionFunction(event) {
    var element = document.querySelector('.chart-x')
    const style = getComputedStyle(element)

    console.log(event.propertyName)
    console.log(event.elapsedTime)
    console.log(event.pseudoElement)

    console.log(style.transitionProperty)
    console.log(style.transitionDuration)
    console.log(style.height)
  }